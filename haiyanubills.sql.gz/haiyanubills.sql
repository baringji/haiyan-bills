-- MySQL dump 10.13  Distrib 5.5.41, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: haiyanubills
-- ------------------------------------------------------
-- Server version	5.5.41-0ubuntu0.14.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `haiyanubills`
--

/*!40000 DROP DATABASE IF EXISTS `haiyanubills`*/;

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `haiyanubills` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `haiyanubills`;

--
-- Table structure for table `bills`
--

DROP TABLE IF EXISTS `bills`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bills` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `amount` decimal(10,4) NOT NULL,
  `due_date` date NOT NULL,
  `period_start` date NOT NULL,
  `period_end` date NOT NULL,
  `details` text COLLATE utf8_unicode_ci NOT NULL,
  `status` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `bills_user_id_foreign` (`user_id`),
  CONSTRAINT `bills_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bills`
--

LOCK TABLES `bills` WRITE;
/*!40000 ALTER TABLE `bills` DISABLE KEYS */;
INSERT INTO `bills` VALUES (1,'Mueller-Runolfsson',708405.8167,'2015-02-06','2015-01-18','2015-01-22','HATED cats: nasty, low, vulgar things! Don\'t let him know she liked them best, For this must be on the glass table as before, \'It\'s all about as it went, \'One side will make you grow taller, and the.','O',2,NULL,NULL,NULL),(2,'Cronin PLC',775916.1091,'2015-02-08','2015-01-29','2015-02-09','ONE with such sudden violence that Alice quite jumped; but she was up to the Mock Turtle is.\' \'It\'s the stupidest tea-party I ever was at the Cat\'s head began fading away the moment how large she.','O',1,NULL,NULL,NULL),(3,'Ruecker PLC',412164.9076,'2015-02-06','2015-01-26','2015-01-27','Alice and all would change to tinkling sheep-bells, and the poor little thing sat down and looked at the Lizard as she went on, \'that they\'d let Dinah stop in the grass, merely remarking as it.','O',3,NULL,NULL,NULL),(4,'Kuphal, Bernier and Casper',954701.0035,'2015-02-14','2015-02-14','2015-02-12','I hadn\'t begun my tea--not above a week or so--and what with the Queen, stamping on the look-out for serpents night and day! Why, I do it again and again.\' \'You are old, Father William,\' the young.','O',1,NULL,NULL,NULL),(5,'Stracke LLC',360483.2670,'2015-01-23','2015-01-23','2015-02-01','Alice thought to herself, (not in a large kitchen, which was immediately suppressed by the end of the others took the regular course.\' \'What was THAT like?\' said Alice. \'And where HAVE my shoulders.','O',1,NULL,NULL,NULL),(6,'Aufderhar PLC',172971.2974,'2015-02-08','2015-01-16','2015-01-20','Why, she\'ll eat a little bit of the conversation. Alice replied, so eagerly that the way YOU manage?\' Alice asked. The Hatter was the first question, you know.\' \'Not at first, the two creatures, who.','O',1,NULL,NULL,NULL),(7,'Kohler-Hyatt',373043.5922,'2015-01-25','2015-02-15','2015-01-24','Hatter, it woke up again as quickly as she went nearer to make out who I am! But I\'d better take him his fan and gloves. \'How queer it seems,\' Alice said very politely, \'for I can\'t be civil, you\'d.','O',1,NULL,NULL,NULL),(8,'Frami-Fadel',413750.2298,'2015-02-02','2015-02-12','2015-01-16','King. Here one of its mouth and began whistling. \'Oh, there\'s no harm in trying.\' So she swallowed one of the house, and found in it about four feet high. \'Whoever lives there,\' thought Alice,.','O',1,NULL,NULL,NULL),(9,'Glover Group',288095.0652,'2015-01-25','2015-01-22','2015-01-23','Duchess\'s knee, while plates and dishes crashed around it--once more the pig-baby was sneezing on the table. \'Nothing can be clearer than THAT. Then again--\"BEFORE SHE HAD THIS FIT--\" you never had.','O',3,NULL,NULL,NULL),(10,'Franecki-Moen',478202.5225,'2015-01-28','2015-02-05','2015-01-24','Alice\'s shoulder, and it was certainly English. \'I don\'t much care where--\' said Alice. \'You must be,\' said the Duchess; \'and most things twinkled after that--only the March Hare said--\' \'I didn\'t!\'.','O',1,NULL,NULL,NULL),(11,'Nader, Hane and Altenwerth',158721.0681,'2015-01-22','2015-01-19','2015-02-05','This question the Dodo managed it.) First it marked out a history of the fact. \'I keep them to sell,\' the Hatter said, tossing his head off outside,\' the Queen was in livery: otherwise, judging by.','O',1,NULL,NULL,NULL),(12,'Jacobs-Williamson',120920.4222,'2015-01-24','2015-01-18','2015-01-22','Pigeon. \'I can hardly breathe.\' \'I can\'t go no lower,\' said the Gryphon. \'I\'ve forgotten the Duchess said to herself. \'Shy, they seem to dry me at all.\' \'In that case,\' said the Mock Turtle with a.','O',1,NULL,NULL,NULL),(13,'Beier, Graham and Beatty',879058.8487,'2015-01-18','2015-02-08','2015-02-09','LITTLE larger, sir, if you cut your finger VERY deeply with a whiting. Now you know.\' \'Who is it twelve? I--\' \'Oh, don\'t talk about wasting IT. It\'s HIM.\' \'I don\'t like the three gardeners, oblong.','O',1,NULL,NULL,NULL),(14,'Hayes-Connelly',65581.7814,'2015-01-19','2015-02-14','2015-01-30','He was looking down with her head!\' the Queen was in confusion, getting the Dormouse indignantly. However, he consented to go on. \'And so these three weeks!\' \'I\'m very sorry you\'ve been annoyed,\'.','O',1,NULL,NULL,NULL),(15,'Oberbrunner, Koch and Schmeler',798153.3058,'2015-01-20','2015-02-01','2015-01-16','The Rabbit Sends in a voice of the ground--and I should frighten them out of THIS!\' (Sounds of more energetic remedies--\' \'Speak English!\' said the Hatter: \'let\'s all move one place on.\' He moved on.','O',1,NULL,NULL,NULL),(16,'Renner, Ziemann and O\'Kon',932222.1391,'2015-02-05','2015-01-21','2015-02-07','You see the earth takes twenty-four hours to turn round on its axis--\' \'Talking of axes,\' said the King. \'When did you ever saw. How she longed to change the subject,\' the March Hare interrupted,.','O',1,NULL,NULL,NULL),(17,'Hyatt, Mraz and Tremblay',412871.4748,'2015-02-10','2015-01-30','2015-01-24','King put on her hand, and Alice called after her. \'I\'ve something important to say!\' This sounded promising, certainly: Alice turned and came flying down upon her: she gave a look askance-- Said he.','O',1,NULL,NULL,NULL),(18,'Funk, Morissette and Kutch',152818.9159,'2015-01-19','2015-02-03','2015-02-05','ME,\' said the one who had been for some time without interrupting it. \'They were obliged to say \'Drink me,\' but the Hatter with a trumpet in one hand and a fan! Quick, now!\' And Alice was not much.','O',3,NULL,NULL,NULL),(19,'Daniel, Auer and Ortiz',507626.5514,'2015-02-08','2015-02-14','2015-01-19','Alice; \'I daresay it\'s a set of verses.\' \'Are they in the other. In the very tones of her going, though she knew that were of the month is it?\' he said. (Which he certainly did NOT, being made.','O',3,NULL,NULL,NULL),(20,'Veum LLC',59081.3063,'2015-02-03','2015-02-15','2015-01-25','March Hare and the little dears came jumping merrily along hand in hand with Dinah, and saying to herself \'That\'s quite enough--I hope I shan\'t grow any more--As it is, I suppose?\' said Alice. \'Why.','O',3,NULL,NULL,NULL),(21,'McKenzie Ltd',587704.6392,'2015-02-02','2015-01-24','2015-01-18','Like a tea-tray in the after-time, be herself a grown woman; and how she was trying to invent something!\' \'I--I\'m a little door into that lovely garden. First, however, she again heard a voice of.','O',2,NULL,NULL,NULL),(22,'Dare, Harber and Kuhic',90838.3150,'2015-02-11','2015-02-05','2015-02-07','I\'m I, and--oh dear, how puzzling it all came different!\' Alice replied very politely, feeling quite pleased to have it explained,\' said the Dodo, pointing to the Dormouse, after thinking a minute.','O',3,NULL,NULL,NULL),(23,'Bruen-Bartoletti',609379.1169,'2015-02-11','2015-02-11','2015-02-07','I was sent for.\' \'You ought to go on. \'And so these three weeks!\' \'I\'m very sorry you\'ve been annoyed,\' said Alice, a good thing!\' she said to herself \'Suppose it should be raving mad--at least not.','O',1,NULL,NULL,NULL),(24,'Ratke-Sanford',781353.7656,'2015-02-04','2015-01-28','2015-02-07','Hatter went on, \'I must be the best way to fly up into the sea, though you mayn\'t believe it--\' \'I never heard it muttering to himself as he spoke, and the fan, and skurried away into the earth. At.','O',1,NULL,NULL,NULL),(25,'Heaney-Ondricka',687643.2248,'2015-01-26','2015-02-10','2015-02-13','Queen, \'and he shall tell you how the Dodo replied very readily: \'but that\'s because it stays the same year for such a thing as \"I get what I eat\" is the use of a well?\' The Dormouse had closed its.','O',1,NULL,NULL,NULL),(26,'Anderson Inc',578250.7638,'2015-01-31','2015-01-27','2015-02-13','He looked at her, and said, \'So you think you\'re changed, do you?\' \'I\'m afraid I don\'t put my arm round your waist,\' the Duchess sneezed occasionally; and as it didn\'t much matter which way I want.','O',3,NULL,NULL,NULL),(27,'Gerlach, Feeney and Ebert',460728.0921,'2015-02-09','2015-01-24','2015-02-02','Off with his knuckles. It was the cat.) \'I hope they\'ll remember her saucer of milk at tea-time. Dinah my dear! Let this be a comfort, one way--never to be a very difficult game indeed. The players.','O',2,NULL,NULL,NULL),(28,'Parisian LLC',297939.8745,'2015-01-15','2015-01-25','2015-02-07','OUTSIDE.\' He unfolded the paper as he could go. Alice took up the chimney, has he?\' said Alice to herself, and shouted out, \'You\'d better not do that again!\' which produced another dead silence..','O',1,NULL,NULL,NULL),(29,'Daniel-McGlynn',753093.4664,'2015-01-20','2015-01-19','2015-01-27','I may as well as if he were trying which word sounded best. Some of the ground.\' So she began nibbling at the White Rabbit, who said in a great letter, nearly as large as himself, and this was the.','O',1,NULL,NULL,NULL),(30,'Swift Inc',32961.9894,'2015-01-22','2015-02-05','2015-01-24','Hatter. \'I deny it!\' said the King. \'I can\'t help it,\' said the King. The White Rabbit with pink eyes ran close by her. There was a good deal: this fireplace is narrow, to be no doubt that it seemed.','O',3,NULL,NULL,NULL),(31,'Steuber, Brekke and Ledner',671693.2120,'2015-01-27','2015-02-02','2015-01-19','Alice had got to the waving of the officers: but the tops of the baby?\' said the Hatter; \'so I should think!\' (Dinah was the first to speak. \'What size do you know what they\'re like.\' \'I believe.','O',3,NULL,NULL,NULL),(32,'Fisher, Brekke and Krajcik',688182.7199,'2015-01-27','2015-01-21','2015-01-26','I try the patience of an oyster!\' \'I wish I hadn\'t quite finished my tea when I got up very carefully, nibbling first at one end to the three gardeners who were all talking together: she made out.','O',2,NULL,NULL,NULL),(33,'Mertz, Mayer and Koelpin',13660.5267,'2015-01-16','2015-02-06','2015-02-15','I do so like that curious song about the same year for such dainties would not join the dance? Will you, won\'t you join the dance? Will you, won\'t you, will you join the dance? Will you, won\'t you,.','O',3,NULL,NULL,NULL),(34,'Simonis-Morissette',884089.9646,'2015-01-24','2015-02-12','2015-01-31','Queen added to one of its mouth again, and we won\'t talk about her and to her chin in salt water. Her first idea was that you weren\'t to talk nonsense. The Queen\'s argument was, that if you please!.','O',2,NULL,NULL,NULL),(35,'Beatty Inc',662889.7368,'2015-01-23','2015-02-09','2015-01-20','Her chin was pressed so closely against her foot, that there was no time she\'d have everybody executed, all round. (It was this last remark, \'it\'s a vegetable. It doesn\'t look like one, but it did.','O',2,NULL,NULL,NULL),(36,'Hilpert, Wiegand and Mitchell',475784.8292,'2015-02-13','2015-01-26','2015-01-24','Alice. \'Off with her friend. When she got up and picking the daisies, when suddenly a White Rabbit read:-- \'They told me you had been jumping about like that!\' said Alice hastily; \'but I\'m not used.','O',1,NULL,NULL,NULL),(37,'Volkman-Moore',746179.9920,'2015-02-05','2015-01-17','2015-02-01','While the Duchess asked, with another hedgehog, which seemed to think this a very little use without my shoulders. Oh, how I wish you were INSIDE, you might knock, and I had it written up.','O',3,NULL,NULL,NULL),(38,'Corwin, Haag and Mosciski',267405.0033,'2015-02-05','2015-01-18','2015-01-24','Be off, or I\'ll have you executed, whether you\'re a little bit of stick, and held out its arms folded, frowning like a steam-engine when she had tired herself out with his head!\' or \'Off with his.','O',2,NULL,NULL,NULL),(39,'Hilll, Thompson and Runte',269574.2079,'2015-01-20','2015-02-14','2015-02-07','She felt that there was no \'One, two, three, and away,\' but they were IN the well,\' Alice said very politely, \'if I had not the same, the next verse,\' the Gryphon at the end.\' \'If you can\'t swim,.','O',1,NULL,NULL,NULL),(40,'Volkman Inc',225243.0089,'2015-02-13','2015-01-16','2015-01-16','Alice, timidly; \'some of the day; and this time the Queen had ordered. They very soon finished it off. \'If everybody minded their own business!\' \'Ah, well! It means much the same thing,\' said the.','O',2,NULL,NULL,NULL),(41,'Lubowitz-Wyman',254531.2655,'2015-01-24','2015-01-16','2015-02-05','Cat\'s head began fading away the moment they saw the White Rabbit, with a trumpet in one hand, and Alice rather unwillingly took the cauldron of soup off the fire, licking her paws and washing her.','O',2,NULL,NULL,NULL),(42,'Monahan, Smith and Kovacek',138737.7219,'2015-02-12','2015-01-23','2015-02-09','Queen. \'I haven\'t the slightest idea,\' said the Hatter. \'Does YOUR watch tell you my adventures--beginning from this side of the tail, and ending with the distant sobs of the what?\' said the.','O',2,NULL,NULL,NULL),(43,'Smith Group',687620.4186,'2015-01-17','2015-01-30','2015-01-16','Father William,\' the young man said, \'And your hair has become very white; And yet you incessantly stand on your head-- Do you think you could draw treacle out of sight. Alice remained looking.','O',3,NULL,NULL,NULL),(44,'Corwin, Zulauf and Friesen',835114.4187,'2015-01-28','2015-02-01','2015-02-14','I shall see it quite plainly through the air! Do you think, at your age, it is you hate--C and D,\' she added in an impatient tone: \'explanations take such a pleasant temper, and thought it had no.','O',3,NULL,NULL,NULL),(45,'Hackett Group',932573.6734,'2015-02-11','2015-02-01','2015-02-15','Alice,) and round goes the clock in a furious passion, and went by without noticing her. Then followed the Knave of Hearts, carrying the King\'s crown on a little wider. \'Come, it\'s pleased so far,\'.','O',3,NULL,NULL,NULL),(46,'Kertzmann, Collier and Leffler',44158.0863,'2015-02-14','2015-01-29','2015-02-01','Alice, in a low voice, to the table, but it puzzled her a good deal frightened by this time). \'Don\'t grunt,\' said Alice; \'living at the top of his shrill little voice, the name again!\' \'I won\'t.','O',1,NULL,NULL,NULL),(47,'Harris PLC',676010.2119,'2015-01-29','2015-02-11','2015-01-30','Rabbit noticed Alice, as she had read about them in books, and she could not help bursting out laughing: and when she heard a little while, however, she again heard a little more conversation with.','O',1,NULL,NULL,NULL),(48,'Rau, Lemke and Champlin',223714.3725,'2015-02-02','2015-01-16','2015-02-10','Lobster Quadrille The Mock Turtle\'s heavy sobs. Lastly, she pictured to herself what such an extraordinary ways of living would be like, \'--for they haven\'t got much evidence YET,\' she said to the.','O',3,NULL,NULL,NULL),(49,'Spinka, Kub and Hegmann',928977.5034,'2015-02-05','2015-01-18','2015-01-23','She gave me a good many little girls of her favourite word \'moral,\' and the March Hare. Alice sighed wearily. \'I think I may as well look and see what was on the Duchess\'s cook. She carried the.','O',1,NULL,NULL,NULL),(50,'Bartell LLC',502389.8825,'2015-02-10','2015-02-14','2015-02-01','For instance, if you cut your finger VERY deeply with a deep voice, \'What are you getting on?\' said the Mock Turtle replied, counting off the subjects on his knee, and looking at it again: but he.','O',3,NULL,NULL,NULL);
/*!40000 ALTER TABLE `bills` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contacts`
--

DROP TABLE IF EXISTS `contacts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contacts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `message` text COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contacts`
--

LOCK TABLES `contacts` WRITE;
/*!40000 ALTER TABLE `contacts` DISABLE KEYS */;
/*!40000 ALTER TABLE `contacts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `files`
--

DROP TABLE IF EXISTS `files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `files` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `file_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `file_type` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `file_type_id` int(10) unsigned NOT NULL,
  `is_primary` tinyint(1) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `files`
--

LOCK TABLES `files` WRITE;
/*!40000 ALTER TABLE `files` DISABLE KEYS */;
/*!40000 ALTER TABLE `files` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `migration` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES ('2015_01_25_072304_create_table_users',1),('2015_01_25_072836_create_table_files',1),('2015_01_25_073429_create_table_bills',1),('2015_01_25_074124_create_table_receipts',1),('2015_01_26_140648_create_table_notes',1),('2015_02_10_020142_create_table_contacts',1);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notes`
--

DROP TABLE IF EXISTS `notes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `details` text COLLATE utf8_unicode_ci NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `notes_user_id_foreign` (`user_id`),
  CONSTRAINT `notes_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notes`
--

LOCK TABLES `notes` WRITE;
/*!40000 ALTER TABLE `notes` DISABLE KEYS */;
/*!40000 ALTER TABLE `notes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `receipts`
--

DROP TABLE IF EXISTS `receipts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `receipts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `amount` decimal(10,4) NOT NULL,
  `bill_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `receipts_bill_id_foreign` (`bill_id`),
  CONSTRAINT `receipts_bill_id_foreign` FOREIGN KEY (`bill_id`) REFERENCES `bills` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `receipts`
--

LOCK TABLES `receipts` WRITE;
/*!40000 ALTER TABLE `receipts` DISABLE KEYS */;
INSERT INTO `receipts` VALUES (1,715673.1821,26,NULL,NULL,NULL),(2,704508.1150,33,NULL,NULL,NULL),(3,684130.1832,34,NULL,NULL,NULL),(4,139789.5803,36,NULL,NULL,NULL),(5,536494.2781,48,NULL,NULL,NULL),(6,477124.6500,39,NULL,NULL,NULL),(7,830313.2559,26,NULL,NULL,NULL),(8,266756.8356,26,NULL,NULL,NULL),(9,217696.8440,47,NULL,NULL,NULL),(10,240063.5801,33,NULL,NULL,NULL);
/*!40000 ALTER TABLE `receipts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `last_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `first_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `middle_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `user_type` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `address` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'administrator','$2y$10$vtsTm7Rmbhtjs2IY6sEroO08K5v8l30vECHOPS4aYXCJNOsEVcrf.','Vandervort','Gerald','Schuster','administrator@haiyanubills.com','0','2452 Leanne Views\nNorth Katlynberg, RI 63409','A',NULL,NULL,NULL,NULL),(2,'admin','$2y$10$qMHVWjfHerU2wV2pUEPLy.ArVW/x.qaFnw0956jH4XHc60uUHNdMu','Muller','Ernestina','Emmerich','admin@haiyanubills.com','1','853 Botsford Spur Suite 117\nEdport, RI 45027','A',NULL,NULL,NULL,NULL),(3,'consumer','$2y$10$qtyWSztGcvlnhwStm6Q6deZabykU6r1Jkw1yG2WJttCsjL1TYy4ky','Marquardt','Alicia','Nitzsche','consumer@haiyanubills.com','2','41599 Kuvalis Village\nWest Vernaland, PA 07781-0057','A',NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-02-15 22:21:54
