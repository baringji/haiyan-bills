-- MySQL dump 10.13  Distrib 5.5.41, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: haiyanubills
-- ------------------------------------------------------
-- Server version	5.5.41-0ubuntu0.14.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `haiyanubills`
--

/*!40000 DROP DATABASE IF EXISTS `haiyanubills`*/;

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `haiyanubills` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `haiyanubills`;

--
-- Table structure for table `bills`
--

DROP TABLE IF EXISTS `bills`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bills` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `amount` decimal(10,4) NOT NULL,
  `due_date` date NOT NULL,
  `period_start` date NOT NULL,
  `period_end` date NOT NULL,
  `details` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `status` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `bills_user_id_foreign` (`user_id`),
  CONSTRAINT `bills_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bills`
--

LOCK TABLES `bills` WRITE;
/*!40000 ALTER TABLE `bills` DISABLE KEYS */;
INSERT INTO `bills` VALUES (1,'Hyatt-Beier',974935.7180,'2015-01-22','2015-01-17','2015-01-06','I know all sorts of things, and she, oh! she knows such a puzzled expression that she had made the whole thing very absurd, but they were filled with cupboards and book-shelves; here and there..','O',2,NULL,NULL,NULL),(2,'Hirthe, Terry and Ankunding',990466.0149,'2015-01-09','2015-01-11','2015-01-23','She generally gave herself very good height indeed!\' said the Caterpillar. This was quite pleased to have the experiment tried. \'Very true,\' said the sage, as he wore his crown over the fire,.','O',2,NULL,NULL,NULL),(3,'Stokes-Watsica',450440.9619,'2015-01-05','2014-12-29','2015-01-14','Gryphon, lying fast asleep in the prisoner\'s handwriting?\' asked another of the table, but it was certainly English. \'I don\'t know what \"it\" means well enough, when I get SOMEWHERE,\' Alice added as.','O',2,NULL,NULL,NULL),(4,'Wiegand-Welch',845513.9394,'2015-01-02','2014-12-27','2015-01-19','Bill! catch hold of anything, but she felt certain it must be what he did not look at it!\' This speech caused a remarkable sensation among the distant sobs of the trial.\' \'Stupid things!\' Alice.','O',2,NULL,NULL,NULL),(5,'Braun Ltd',90226.7389,'2015-01-22','2015-01-08','2015-01-15','And the moral of that is--\"Birds of a bottle. They all made of solid glass; there was a different person then.\' \'Explain all that,\' said Alice. \'Who\'s making personal remarks now?\' the Hatter.','O',1,NULL,NULL,NULL),(6,'Koepp PLC',977941.3528,'2015-01-18','2015-01-03','2015-01-21','Cat. \'I don\'t know one,\' said Alice. \'Why, SHE,\' said the Gryphon, the squeaking of the tea--\' \'The twinkling of the evening, beautiful Soup! Beau--ootiful Soo--oop! Beau--ootiful Soo--oop!.','O',1,NULL,NULL,NULL),(7,'O\'Conner-Morar',583646.5686,'2015-01-12','2015-01-13','2015-01-16','That he met in the sea!\' cried the Gryphon, \'that they WOULD go with Edgar Atheling to meet William and offer him the crown. William\'s conduct at first she would gather about her pet: \'Dinah\'s our.','O',3,NULL,NULL,NULL),(8,'Lebsack-Hegmann',601677.2331,'2015-01-24','2015-01-24','2014-12-29','King, \'that saves a world of trouble, you know, and he says it\'s so useful, it\'s worth a hundred pounds! He says it kills all the things between whiles.\' \'Then you shouldn\'t talk,\' said the Hatter..','O',2,NULL,NULL,NULL),(9,'Bashirian and Sons',611896.2069,'2015-01-08','2015-01-18','2015-01-12','Beautiful, beauti--FUL SOUP!\' \'Chorus again!\' cried the Mouse, turning to the jury, who instantly made a rush at Alice as he spoke, and added with a deep voice, \'What are you thinking of?\' \'I beg.','O',3,NULL,NULL,NULL),(10,'Friesen-Schinner',194011.2480,'2014-12-25','2015-01-21','2015-01-15','King very decidedly, and the other side of the gloves, and was beating her violently with its eyelids, so he did,\' said the Mock Turtle, \'but if they do, why then they\'re a kind of authority over.','O',1,NULL,NULL,NULL),(11,'Gleichner Inc',273445.3716,'2015-01-17','2015-01-05','2015-01-14','Dormouse fell asleep instantly, and neither of the party went back to the end: then stop.\' These were the verses on his knee, and the party went back to the Queen. \'Can you play croquet?\' The.','O',1,NULL,NULL,NULL),(12,'Huels-Lehner',785956.3203,'2014-12-31','2015-01-18','2014-12-31','Hatter, and he called the Queen, \'and take this child away with me,\' thought Alice, \'it\'ll never do to come down the chimney?--Nay, I shan\'t! YOU do it!--That I won\'t, then!--Bill\'s to go from.','O',3,NULL,NULL,NULL),(13,'Moen, Brown and Price',187455.0505,'2015-01-07','2015-01-01','2015-01-03','DOES THE BOOTS AND SHOES.\' the Gryphon in an offended tone, \'so I can\'t take LESS,\' said the Gryphon: and Alice rather unwillingly took the place of the guinea-pigs cheered, and was beating her.','O',2,NULL,NULL,NULL),(14,'Christiansen LLC',634636.2591,'2014-12-31','2015-01-12','2015-01-06','Alice alone with the Gryphon. \'Turn a somersault in the middle of the water, and seemed not to be said. At last the Mock Turtle, who looked at it uneasily, shaking it every now and then; such as,.','O',2,NULL,NULL,NULL),(15,'Farrell LLC',985170.9420,'2015-01-08','2014-12-31','2015-01-24','Rabbit began. Alice thought to herself \'Now I can find out the Fish-Footman was gone, and the shrill voice of the words came very queer indeed:-- \'\'Tis the voice of the court. \'What do you want to.','O',3,NULL,NULL,NULL),(16,'Kshlerin Ltd',874632.5260,'2015-01-09','2015-01-06','2015-01-12','I hardly know--No more, thank ye; I\'m better now--but I\'m a deal too flustered to tell them something more. \'You promised to tell him. \'A nice muddle their slates\'ll be in before the officer could.','O',3,NULL,NULL,NULL),(17,'Hand Group',878945.5720,'2015-01-06','2015-01-04','2014-12-31','Alice to herself, rather sharply; \'I advise you to offer it,\' said the Mock Turtle\'s Story \'You can\'t think how glad I am to see what was going to dive in among the leaves, which she had hurt the.','O',1,NULL,NULL,NULL),(18,'Veum Inc',963020.4159,'2015-01-16','2015-01-21','2015-01-12','I think?\' \'I had NOT!\' cried the Mouse, who was beginning to think to herself, (not in a low, weak voice. \'Now, I give you fair warning,\' shouted the Gryphon, half to Alice. \'What IS the use of a.','O',1,NULL,NULL,NULL),(19,'Jacobson Ltd',983387.8736,'2014-12-25','2015-01-03','2015-01-15','Hatter; \'so I should be like then?\' And she began again. \'I should like to try the first really clever thing the King sharply. \'Do you mean \"purpose\"?\' said Alice. \'Come on, then!\' roared the Queen,.','O',1,NULL,NULL,NULL),(20,'Weimann-Lindgren',497692.4531,'2014-12-31','2014-12-30','2015-01-22','Mock Turtle to the Gryphon. \'Then, you know,\' said the Footman. \'That\'s the judge,\' she said this, she came upon a low voice, to the door. \'Call the next moment a shower of little cartwheels, and.','O',3,NULL,NULL,NULL),(21,'Zieme-Mosciski',858559.7561,'2015-01-07','2014-12-29','2015-01-02','No, no! You\'re a serpent; and there\'s no use going back to the dance. Would not, could not, could not, would not, could not, would not allow without knowing how old it was, even before she made out.','O',1,NULL,NULL,NULL),(22,'Leuschke, Heller and Ritchie',481078.7795,'2015-01-14','2015-01-09','2014-12-29','Why, she\'ll eat a bat?\' when suddenly, thump! thump! down she came up to the little door, had vanished completely. Very soon the Rabbit whispered in a melancholy tone. \'Nobody seems to be ashamed of.','O',2,NULL,NULL,NULL),(23,'Kiehn, Quitzon and Tillman',804322.2784,'2015-01-22','2015-01-11','2015-01-16','I then? Tell me that first, and then sat upon it.) \'I\'m glad I\'ve seen that done,\' thought Alice. \'I\'m glad they\'ve begun asking riddles.--I believe I can creep under the sea--\' (\'I haven\'t,\' said.','O',1,NULL,NULL,NULL),(24,'Paucek and Sons',745831.7131,'2015-01-18','2015-01-11','2015-01-22','I am in the schoolroom, and though this was of very little use without my shoulders. Oh, how I wish I had to fall upon Alice, as she picked up a little snappishly. \'You\'re enough to try the effect:.','O',3,NULL,NULL,NULL),(25,'Abshire, Kozey and Kub',222740.4182,'2015-01-21','2015-01-25','2014-12-26','I will tell you just now what the moral of that is--\"The more there is of mine, the less there is of finding morals in things!\' Alice thought she might as well to say \'I once tasted--\' but checked.','O',1,NULL,NULL,NULL),(26,'Brekke, Effertz and Jones',989918.8840,'2015-01-12','2015-01-13','2015-01-15','Heads below!\' (a loud crash)--\'Now, who did that?--It was Bill, the Lizard) could not join the dance. So they went up to her daughter \'Ah, my dear! Let this be a person of authority among them,.','O',3,NULL,NULL,NULL),(27,'Koch and Sons',368565.6203,'2015-01-01','2015-01-16','2015-01-19','I--\' \'Oh, don\'t bother ME,\' said Alice to find her in such confusion that she never knew so much at this, that she had finished, her sister sat still and said to the jury. \'Not yet, not yet!\' the.','O',1,NULL,NULL,NULL),(28,'Weber Inc',592313.3933,'2015-01-13','2015-01-07','2015-01-09','Gryphon: \'I went to school in the pool as it was quite out of THIS!\' (Sounds of more energetic remedies--\' \'Speak English!\' said the Queen. \'Well, I never heard it before,\' said the Dormouse. \'Don\'t.','O',2,NULL,NULL,NULL),(29,'Trantow-Quigley',779491.8492,'2015-01-19','2014-12-29','2015-01-01','I beat him when he finds out who I WAS when I got up and rubbed its eyes: then it watched the Queen in a furious passion, and went in. The door led right into a conversation. Alice felt so desperate.','O',1,NULL,NULL,NULL),(30,'Lakin, Kshlerin and Berge',969572.2078,'2015-01-03','2015-01-01','2015-01-09','March Hare moved into the book her sister on the stairs. Alice knew it was in the distance. \'And yet what a wonderful dream it had come back in a tone of great relief. \'Call the first figure!\' said.','O',3,NULL,NULL,NULL),(31,'Jenkins Group',66472.1123,'2015-01-15','2015-01-08','2015-01-21','What happened to me! When I used to read fairy-tales, I fancied that kind of rule, \'and vinegar that makes them sour--and camomile that makes you forget to talk. I can\'t take more.\' \'You mean you.','O',1,NULL,NULL,NULL),(32,'Walter Ltd',883356.2652,'2015-01-12','2015-01-15','2014-12-28','ME.\' \'You!\' said the Gryphon. \'It all came different!\' Alice replied in an undertone, \'important--unimportant--unimportant--important--\' as if it makes rather a complaining tone, \'and they drew all.','O',2,NULL,NULL,NULL),(33,'Feest Inc',83880.6284,'2015-01-02','2015-01-19','2014-12-26','She said the Caterpillar seemed to Alice a little bit of stick, and tumbled head over heels in its sleep \'Twinkle, twinkle, twinkle, twinkle--\' and went stamping about, and make THEIR eyes bright.','O',1,NULL,NULL,NULL),(34,'Mayer, Eichmann and Nikolaus',197644.1414,'2015-01-15','2015-01-06','2014-12-29','CAN have happened to you? Tell us all about as much as she went to the garden door. Poor Alice! It was as much as she could not taste theirs, and the cool fountains. CHAPTER VIII. The Queen\'s.','O',2,NULL,NULL,NULL),(35,'Ward, Lowe and Dicki',291790.3246,'2014-12-27','2015-01-10','2014-12-26','English!\' said the Duchess, who seemed too much overcome to do it.\' (And, as you liked.\' \'Is that all?\' said Alice, who felt very curious to know when the Rabbit say to itself, half to Alice..','O',3,NULL,NULL,NULL),(36,'Ferry-D\'Amore',320876.2138,'2015-01-18','2014-12-30','2015-01-22','Mock Turtle, \'Drive on, old fellow! Don\'t be all day to day.\' This was quite out of the tea--\' \'The twinkling of the busy farm-yard--while the lowing of the house!\' (Which was very uncomfortable,.','O',2,NULL,NULL,NULL),(37,'Leffler Ltd',110342.3956,'2014-12-30','2015-01-14','2015-01-11','CHORUS. \'Wow! wow! wow!\' While the Duchess began in a hurry: a large caterpillar, that was linked into hers began to cry again. \'You ought to be two people! Why, there\'s hardly room to open them.','O',3,NULL,NULL,NULL),(38,'Weber-Langosh',691633.1837,'2015-01-09','2014-12-31','2015-01-19','Alice said very politely, \'if I had to pinch it to be lost, as she heard something like it,\' said the March Hare, \'that \"I breathe when I was sent for.\' \'You ought to be afraid of interrupting him,).','O',3,NULL,NULL,NULL),(39,'Boehm and Sons',551988.5561,'2015-01-15','2015-01-11','2014-12-26','I used to do:-- \'How doth the little--\"\' and she had finished, her sister kissed her, and the words a little, half expecting to see that she was now about a foot high: then she walked off, leaving.','O',3,NULL,NULL,NULL),(40,'Boehm Ltd',878262.9761,'2015-01-06','2015-01-23','2015-01-17','The Mouse did not dare to laugh; and, as there seemed to be otherwise than what you like,\' said the one who got any advantage from the Gryphon, \'that they WOULD put their heads down and began bowing.','O',2,NULL,NULL,NULL),(41,'Kilback Inc',589112.2476,'2015-01-23','2015-01-02','2015-01-10','Pennyworth only of beautiful Soup? Pennyworth only of beautiful Soup? Pennyworth only of beautiful Soup? Beau--ootiful Soo--oop! Soo--oop of the moment they saw the Mock Turtle, and to hear it say,.','O',3,NULL,NULL,NULL),(42,'Kovacek-Gaylord',349156.6458,'2015-01-15','2015-01-06','2015-01-24','King said to herself, \'the way all the while, and fighting for the immediate adoption of more energetic remedies--\' \'Speak English!\' said the Cat. \'I don\'t see,\' said the Caterpillar, just as well.','O',1,NULL,NULL,NULL),(43,'Kulas-Huel',139263.7845,'2014-12-28','2014-12-30','2015-01-22','WAS a narrow escape!\' said Alice, as she could not remember ever having heard of \"Uglification,\"\' Alice ventured to remark. \'Tut, tut, child!\' said the Rabbit coming to look at me like that!\' \'I.','O',1,NULL,NULL,NULL),(44,'Durgan, Kuvalis and Carroll',927339.5471,'2015-01-01','2015-01-22','2014-12-30','CHAPTER VIII. The Queen\'s argument was, that she was now about a whiting before.\' \'I can tell you how it was in livery: otherwise, judging by his garden.\"\' Alice did not like to hear his history. I.','O',2,NULL,NULL,NULL),(45,'Auer, Ziemann and Nienow',600546.4652,'2015-01-15','2015-01-11','2015-01-05','Caterpillar angrily, rearing itself upright as it can be,\' said the Footman, \'and that for the hedgehogs; and in another moment, splash! she was up to the law, And argued each case with MINE,\' said.','O',2,NULL,NULL,NULL),(46,'Bartell, Corkery and Bauch',906775.4874,'2015-01-07','2014-12-27','2015-01-16','WAS a narrow escape!\' said Alice, whose thoughts were still running on the hearth and grinning from ear to ear. \'Please would you like to hear her try and say \"How doth the little--\"\' and she put.','O',3,NULL,NULL,NULL),(47,'Walker-Barrows',461729.8771,'2015-01-10','2015-01-10','2015-01-06','Gryphon is, look at the sides of it, and found that, as nearly as large as himself, and this was of very little use, as it left no mark on the table. \'Have some wine,\' the March Hare, who had spoken.','O',1,NULL,NULL,NULL),(48,'Durgan Inc',797387.5797,'2015-01-06','2015-01-17','2015-01-18','Crab, a little animal (she couldn\'t guess of what work it would be quite as much as serpents do, you know.\' \'I DON\'T know,\' said Alice very politely; but she remembered how small she was quite pale.','O',3,NULL,NULL,NULL),(49,'Wiegand, Koelpin and Hyatt',362226.8222,'2015-01-14','2015-01-10','2015-01-03','Gryphon. \'How the creatures wouldn\'t be so easily offended, you know!\' The Mouse gave a little scream, half of anger, and tried to curtsey as she could. \'No,\' said the Queen say only yesterday you.','O',1,NULL,NULL,NULL),(50,'Collier-Blanda',24186.0077,'2015-01-08','2015-01-13','2014-12-31','Gryphon. Alice did not appear, and after a few minutes she heard a little different. But if I\'m not Ada,\' she said, by way of keeping up the little golden key and hurried off at once, and ran off,.','O',2,NULL,NULL,NULL);
/*!40000 ALTER TABLE `bills` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `files`
--

DROP TABLE IF EXISTS `files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `files` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `file_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `file_type` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `file_type_id` int(10) unsigned NOT NULL,
  `is_primary` tinyint(1) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `files`
--

LOCK TABLES `files` WRITE;
/*!40000 ALTER TABLE `files` DISABLE KEYS */;
/*!40000 ALTER TABLE `files` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `landmarks`
--

DROP TABLE IF EXISTS `landmarks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `landmarks` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `type` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `latitude` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `longitude` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `landmarks`
--

LOCK TABLES `landmarks` WRITE;
/*!40000 ALTER TABLE `landmarks` DISABLE KEYS */;
INSERT INTO `landmarks` VALUES (1,'Murray-Moen','PARK','-20.638282','102.837466',NULL,NULL,NULL),(2,'Weber and Sons','BUILDING','-1.58422','-137.650428',NULL,NULL,NULL),(3,'Kuhn-Rosenbaum','CHURCH','24.479259','-2.060167',NULL,NULL,NULL),(4,'Reinger-Hackett','CHURCH','38.21715','100.692396',NULL,NULL,NULL),(5,'Aufderhar-Daniel','HOTEL','83.317735','147.42634',NULL,NULL,NULL),(6,'Weimann Group','HOTEL','29.048376','-39.770468',NULL,NULL,NULL),(7,'O\'Hara and Sons','HOTEL','79.462217','-25.809899',NULL,NULL,NULL),(8,'Frami Ltd','HOTEL','59.265591','-141.469857',NULL,NULL,NULL),(9,'Balistreri PLC','HOTEL','-80.285272','124.41612',NULL,NULL,NULL),(10,'Crist LLC','MALL','-76.012986','144.693318',NULL,NULL,NULL),(11,'Ullrich-Spencer','BUILDING','-6.360176','175.099702',NULL,NULL,NULL),(12,'Spinka Group','MALL','-13.631364','121.332545',NULL,NULL,NULL),(13,'Kreiger-Huels','CHURCH','19.011063','-178.741249',NULL,NULL,NULL),(14,'Greenholt-Reichel','BUILDING','76.695626','-173.6345',NULL,NULL,NULL),(15,'Howe Ltd','MALL','-35.833035','-52.065406',NULL,NULL,NULL),(16,'Kulas Group','MALL','-58.522652','-71.100662',NULL,NULL,NULL),(17,'Mraz PLC','PARK','-4.596633','-20.349115',NULL,NULL,NULL),(18,'Purdy LLC','CHURCH','11.069893','-42.728377',NULL,NULL,NULL),(19,'Lueilwitz LLC','CHURCH','57.96097','-163.206868',NULL,NULL,NULL),(20,'Ziemann-Nitzsche','BUILDING','-74.615685','34.974411',NULL,NULL,NULL),(21,'Mertz-Johnston','CHURCH','73.977439','128.011137',NULL,NULL,NULL),(22,'Windler-Wilkinson','BUILDING','73.134018','-113.839678',NULL,NULL,NULL),(23,'Beier, Mosciski and Parker','BUILDING','-30.471225','-42.826073',NULL,NULL,NULL),(24,'Zboncak Group','MALL','-11.165585','37.698414',NULL,NULL,NULL),(25,'Mitchell, Cassin and Waelchi','PARK','-8.38268','166.104749',NULL,NULL,NULL),(26,'White PLC','HOTEL','-36.438653','139.491954',NULL,NULL,NULL),(27,'Mills, Mayert and Mayert','BUILDING','-4.518515','-177.100004',NULL,NULL,NULL),(28,'Erdman, Mann and Kerluke','BUILDING','68.403776','-56.644603',NULL,NULL,NULL),(29,'O\'Hara, Will and Schoen','HOTEL','84.591012','-42.081908',NULL,NULL,NULL),(30,'Hane, McClure and Terry','PARK','-28.102545','-92.267307',NULL,NULL,NULL),(31,'Kihn Inc','MALL','29.028116','89.261011',NULL,NULL,NULL),(32,'Walker-Cremin','BUILDING','-86.58042','95.134437',NULL,NULL,NULL),(33,'Braun PLC','BUILDING','27.982537','160.030061',NULL,NULL,NULL),(34,'Padberg and Sons','MALL','69.286942','-65.507872',NULL,NULL,NULL),(35,'Hintz-Kautzer','PARK','-34.171944','27.951723',NULL,NULL,NULL),(36,'Powlowski-Russel','HOTEL','-44.739667','86.702652',NULL,NULL,NULL),(37,'Prosacco-Block','MALL','-53.215134','173.013379',NULL,NULL,NULL),(38,'Pollich, Bernhard and Wilderman','CHURCH','-64.705989','172.300143',NULL,NULL,NULL),(39,'Ledner-Grady','MALL','-49.414496','101.690635',NULL,NULL,NULL),(40,'Keebler, Rice and Carroll','BUILDING','83.083137','10.320204',NULL,NULL,NULL),(41,'Parker PLC','MALL','19.447802','-88.791672',NULL,NULL,NULL),(42,'Pfeffer, Haag and Terry','BUILDING','39.393434','66.65572',NULL,NULL,NULL),(43,'Fritsch LLC','HOTEL','-29.333168','-40.693701',NULL,NULL,NULL),(44,'Kling PLC','BUILDING','-89.679884','-39.722596',NULL,NULL,NULL),(45,'Satterfield, Gleichner and Herman','CHURCH','78.931971','97.207639',NULL,NULL,NULL),(46,'Nader-Marks','CHURCH','54.960234','-134.909783',NULL,NULL,NULL),(47,'Hand Inc','MALL','24.546352','149.83988',NULL,NULL,NULL),(48,'O\'Kon, Emmerich and Bartell','CHURCH','68.866289','32.196131',NULL,NULL,NULL),(49,'Krajcik-Schroeder','BUILDING','17.478039','-72.56258',NULL,NULL,NULL),(50,'Mante and Sons','MALL','3.734729','122.387391',NULL,NULL,NULL);
/*!40000 ALTER TABLE `landmarks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `migration` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES ('2015_01_25_072304_create_table_users',1),('2015_01_25_072836_create_table_files',1),('2015_01_25_073429_create_table_bills',1),('2015_01_25_074124_create_table_receipts',1),('2015_01_25_075327_create_table_payment_centers',1),('2015_01_25_075841_create_table_landmarks',1),('2015_01_25_080038_create_table_payment_centers_landmarks',1);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payment_centers`
--

DROP TABLE IF EXISTS `payment_centers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payment_centers` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `city` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `country` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `zip` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `latitude` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `longitude` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payment_centers`
--

LOCK TABLES `payment_centers` WRITE;
/*!40000 ALTER TABLE `payment_centers` DISABLE KEYS */;
INSERT INTO `payment_centers` VALUES (1,'Toy, Daugherty and Orn','213 Reagan Gateway Apt. 650','West Dameonfort','Egypt','60321','-8.67905','-144.040924',NULL,NULL,NULL),(2,'Yost, Gaylord and Renner','04426 Armstrong Turnpike Apt. 901','New D\'angelobury','United Kingdom','21769','16.973877','-19.987636',NULL,NULL,NULL),(3,'Schinner-Reinger','3436 Bradtke Ways','Fayland','Micronesia','99157','-78.911351','-103.107373',NULL,NULL,NULL),(4,'Osinski Ltd','1884 Oberbrunner Isle','East Bertram','Bahrain','51437-8772','-41.393831','81.249394',NULL,NULL,NULL),(5,'Kassulke, Wisoky and Waters','20451 Becker Prairie Apt. 200','Wiltonside','Azerbaijan','30501-7415','-87.938375','23.978853',NULL,NULL,NULL),(6,'Grant-O\'Connell','3968 Norwood Crescent','Lukasstad','Portugal','66972','7.472689','-107.241288',NULL,NULL,NULL),(7,'O\'Hara-Gerhold','3906 Sage Shoals Suite 417','Port Myronhaven','Kyrgyz Republic','84743','35.672584','-51.040246',NULL,NULL,NULL),(8,'Brown, Effertz and Grimes','5636 Marguerite Island Suite 238','Alysonstad','Papua New Guinea','45773-3587','73.567994','30.966747',NULL,NULL,NULL),(9,'Schoen LLC','534 Aniya Wall Apt. 327','Doloresport','Niue','80721-9901','29.940687','-28.24587',NULL,NULL,NULL),(10,'Rohan Group','40172 Lebsack Heights Apt. 977','Lake Bettye','Iraq','97998','-16.883068','-101.034971',NULL,NULL,NULL),(11,'Hoeger-Roob','9777 Spinka Expressway Apt. 817','North Bethelview','Tunisia','17947-1419','57.533984','9.808739',NULL,NULL,NULL),(12,'Langworth Inc','393 Gutkowski View','North Israelland','American Samoa','63377','15.480891','158.499255',NULL,NULL,NULL),(13,'Wyman, Feil and Gutmann','727 Oleta Lodge Apt. 906','Grimesshire','Belgium','18321','6.95428','-74.79399',NULL,NULL,NULL),(14,'Hane-Kling','0173 Ofelia Canyon','North Evalynhaven','Burkina Faso','94131','19.133971','-153.67743',NULL,NULL,NULL),(15,'Purdy and Sons','8118 Lydia Dale','East Ivy','Latvia','98287-6824','78.038244','26.051793',NULL,NULL,NULL),(16,'Farrell Inc','921 Rohan Roads Suite 369','Port Nakia','Papua New Guinea','05266','33.620675','-5.886448',NULL,NULL,NULL),(17,'Bechtelar Group','86852 Crystel Mountain','North Tiannaville','Faroe Islands','25951-5949','-5.371324','111.090144',NULL,NULL,NULL),(18,'Feeney and Sons','79044 Jameson Meadows','Bentontown','Slovakia (Slovak Republic)','20495-9202','-3.712275','59.582499',NULL,NULL,NULL),(19,'Kuvalis and Sons','7381 Pouros Parks Apt. 387','Caylashire','Heard Island and McDonald Islands','97161','8.86705','95.973878',NULL,NULL,NULL),(20,'Balistreri-Hartmann','445 Merle Square','New Laurie','Jordan','44653','-9.813079','-23.274171',NULL,NULL,NULL),(21,'Doyle, O\'Hara and Gorczany','6015 Emmy Tunnel Suite 726','West Bettyfort','Falkland Islands (Malvinas)','72737-2482','39.963936','113.708634',NULL,NULL,NULL),(22,'Herman and Sons','9494 Jaydon Island Apt. 559','Porterland','Libyan Arab Jamahiriya','16413','54.754818','150.342547',NULL,NULL,NULL),(23,'Leuschke LLC','1703 Schoen Rue Suite 370','West Adan','Australia','52499-6697','61.82061','32.405145',NULL,NULL,NULL),(24,'Conn PLC','297 Tyreek Rapids','East Fritzview','Iceland','64786-0143','-40.729354','146.028919',NULL,NULL,NULL),(25,'Bode LLC','689 Lockman Vista','East Johannashire','Aruba','07628-7973','5.334141','113.041944',NULL,NULL,NULL),(26,'Ritchie-Spinka','241 Lucile Ridges','Millsside','Wallis and Futuna','53068-0947','86.287804','-91.111136',NULL,NULL,NULL),(27,'D\'Amore-Cummings','93517 Herman Harbor Suite 274','Homenickton','Niue','14578','22.633802','-5.45543',NULL,NULL,NULL),(28,'Schowalter-Schowalter','11727 Hyatt Ferry','Lindgrenland','Kiribati','90268-7240','14.57896','-82.33099',NULL,NULL,NULL),(29,'Lowe PLC','06716 Romaguera Walks Suite 844','North Levi','French Polynesia','34218','-59.83803','-43.641104',NULL,NULL,NULL),(30,'Carroll, Bernier and Abernathy','883 Bahringer Glen','Sherwoodburgh','Niue','92434','29.049203','-42.420324',NULL,NULL,NULL),(31,'Ruecker-Johnson','25212 Zachery Ford','New Wade','Afghanistan','74016-3958','88.881424','76.548867',NULL,NULL,NULL),(32,'Quigley-Walker','32959 Helen Cape','East Jamisonfurt','Egypt','23531-6229','40.137668','143.917651',NULL,NULL,NULL),(33,'Heathcote, Gusikowski and Cole','5176 Litzy Fork Suite 150','Monahanstad','Saint Kitts and Nevis','63403-1420','-72.346972','-14.240296',NULL,NULL,NULL),(34,'Lind Ltd','7270 Koss Centers','West Marquis','Rwanda','70984-6816','68.477442','-82.439157',NULL,NULL,NULL),(35,'Kuphal Ltd','766 Muhammad Lakes Suite 746','West Kristina','Israel','40247','-19.548587','-126.691741',NULL,NULL,NULL),(36,'Rohan PLC','5648 Kendra Mount','Runolfssonfurt','Central African Republic','28455-3073','55.769776','59.446857',NULL,NULL,NULL),(37,'Schulist, Stark and Morissette','130 Swaniawski Haven Suite 152','South Sofia','Pitcairn Islands','19027-3689','68.302739','-129.709952',NULL,NULL,NULL),(38,'Hodkiewicz LLC','349 Metz Common','Port Osborneview','Guyana','85024-9225','-31.177605','35.152048',NULL,NULL,NULL),(39,'Larson-Braun','1136 Yvette Lights Apt. 995','South Wilhelmland','Faroe Islands','81277-3058','46.442683','-19.307215',NULL,NULL,NULL),(40,'Maggio and Sons','57994 Abelardo Mountain Suite 604','Rubyebury','Bahamas','70107','-48.018327','-140.805902',NULL,NULL,NULL),(41,'Kertzmann, Jaskolski and Bogan','97482 Claudine Forks','South Ethafurt','French Polynesia','67625-4368','-82.783524','80.250853',NULL,NULL,NULL),(42,'Wunsch, Sanford and Roob','2065 Lakin Plaza Suite 790','Kohlerborough','Vietnam','61619-5524','72.461741','-147.829925',NULL,NULL,NULL),(43,'Marks-Konopelski','418 Kelsi Mount Apt. 975','West Hailey','Dominica','33290-5792','79.699812','152.469124',NULL,NULL,NULL),(44,'Kulas-Sanford','5039 Alvah River Suite 859','South Diana','Mozambique','69699-3031','82.263023','1.287378',NULL,NULL,NULL),(45,'Hirthe, Beatty and Luettgen','13488 Jones Locks','New Roselyn','Malawi','52865-0251','-72.191867','-153.657504',NULL,NULL,NULL),(46,'Simonis-Hessel','0001 Erna Lights','Boscostad','Tanzania','39635','-74.211498','-148.873903',NULL,NULL,NULL),(47,'Hartmann-Mitchell','83171 Feest Parkways','Vandervortland','Panama','40009','-16.681962','-110.854208',NULL,NULL,NULL),(48,'Weissnat-Tromp','854 Guadalupe Coves Apt. 156','Volkmantown','Costa Rica','27971-0633','-20.309731','-158.749353',NULL,NULL,NULL),(49,'Zboncak, Rippin and Jast','805 Antoinette Fords','Rempelport','Belgium','24971','42.622438','-157.956384',NULL,NULL,NULL),(50,'Johnston PLC','01620 Amaya Mews','Urielbury','Armenia','06547','57.757032','71.157539',NULL,NULL,NULL);
/*!40000 ALTER TABLE `payment_centers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payment_centers_landmarks`
--

DROP TABLE IF EXISTS `payment_centers_landmarks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payment_centers_landmarks` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `payment_center_id` int(10) unsigned NOT NULL,
  `landmark_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `payment_centers_landmarks_payment_center_id_foreign` (`payment_center_id`),
  KEY `payment_centers_landmarks_landmark_id_foreign` (`landmark_id`),
  CONSTRAINT `payment_centers_landmarks_landmark_id_foreign` FOREIGN KEY (`landmark_id`) REFERENCES `landmarks` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `payment_centers_landmarks_payment_center_id_foreign` FOREIGN KEY (`payment_center_id`) REFERENCES `payment_centers` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payment_centers_landmarks`
--

LOCK TABLES `payment_centers_landmarks` WRITE;
/*!40000 ALTER TABLE `payment_centers_landmarks` DISABLE KEYS */;
INSERT INTO `payment_centers_landmarks` VALUES (1,31,25,NULL,NULL,NULL),(2,3,20,NULL,NULL,NULL),(3,43,45,NULL,NULL,NULL),(4,9,10,NULL,NULL,NULL),(5,39,11,NULL,NULL,NULL),(6,4,25,NULL,NULL,NULL),(7,37,6,NULL,NULL,NULL),(8,2,46,NULL,NULL,NULL),(9,7,11,NULL,NULL,NULL),(10,35,31,NULL,NULL,NULL),(11,40,17,NULL,NULL,NULL),(12,46,49,NULL,NULL,NULL),(13,29,50,NULL,NULL,NULL),(14,11,27,NULL,NULL,NULL),(15,27,8,NULL,NULL,NULL),(16,18,8,NULL,NULL,NULL),(17,33,21,NULL,NULL,NULL),(18,27,26,NULL,NULL,NULL),(19,15,35,NULL,NULL,NULL),(20,35,4,NULL,NULL,NULL),(21,45,39,NULL,NULL,NULL),(22,28,32,NULL,NULL,NULL),(23,44,30,NULL,NULL,NULL),(24,28,1,NULL,NULL,NULL),(25,40,13,NULL,NULL,NULL),(26,31,29,NULL,NULL,NULL),(27,30,26,NULL,NULL,NULL),(28,28,8,NULL,NULL,NULL),(29,26,39,NULL,NULL,NULL),(30,34,3,NULL,NULL,NULL),(31,47,2,NULL,NULL,NULL),(32,10,29,NULL,NULL,NULL),(33,22,37,NULL,NULL,NULL),(34,5,37,NULL,NULL,NULL),(35,21,39,NULL,NULL,NULL),(36,40,16,NULL,NULL,NULL),(37,28,17,NULL,NULL,NULL),(38,48,21,NULL,NULL,NULL),(39,47,26,NULL,NULL,NULL),(40,21,37,NULL,NULL,NULL),(41,39,2,NULL,NULL,NULL),(42,16,18,NULL,NULL,NULL),(43,28,43,NULL,NULL,NULL),(44,26,3,NULL,NULL,NULL),(45,31,10,NULL,NULL,NULL),(46,5,27,NULL,NULL,NULL),(47,11,15,NULL,NULL,NULL),(48,6,32,NULL,NULL,NULL),(49,1,10,NULL,NULL,NULL),(50,18,22,NULL,NULL,NULL);
/*!40000 ALTER TABLE `payment_centers_landmarks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `receipts`
--

DROP TABLE IF EXISTS `receipts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `receipts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `amount` decimal(10,4) NOT NULL,
  `bill_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `receipts_bill_id_foreign` (`bill_id`),
  CONSTRAINT `receipts_bill_id_foreign` FOREIGN KEY (`bill_id`) REFERENCES `bills` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `receipts`
--

LOCK TABLES `receipts` WRITE;
/*!40000 ALTER TABLE `receipts` DISABLE KEYS */;
INSERT INTO `receipts` VALUES (1,516341.6526,32,NULL,NULL,NULL),(2,679963.1386,20,NULL,NULL,NULL),(3,55558.8299,1,NULL,NULL,NULL),(4,428805.2565,38,NULL,NULL,NULL),(5,455377.5254,19,NULL,NULL,NULL),(6,588201.4765,10,NULL,NULL,NULL),(7,533671.5549,30,NULL,NULL,NULL),(8,966070.8259,29,NULL,NULL,NULL),(9,768698.8702,30,NULL,NULL,NULL),(10,508029.0663,38,NULL,NULL,NULL);
/*!40000 ALTER TABLE `receipts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `last_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `first_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `middle_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `user_type` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `address` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'administrator','$2y$10$1diHG.HMUFhH3GPif8v8KuQrfaEsR3hPCxDmQ4n5stfpfhn.Oj.2O','Goyette','Libby','Oberbrunner','administrator@haiyanubills.com','0','2812 Justus Union\nAndreannehaven, AR 44026','A',NULL,NULL,NULL,NULL),(2,'admin','$2y$10$xMMsKCEGbBPd/yynETG2Suxbc3MeRJIYt7XG8GV3j7wl3dAtHz6dK','Mitchell','Jack','Donnelly','admin@haiyanubills.com','1','181 Anya Brooks Apt. 204\nBoehmfurt, VT 16313','A',NULL,NULL,NULL,NULL),(3,'consumer','$2y$10$Aq9kYC4Muo1O6.Jr.Lofaue5RinUHKW5EAJgxqIFasgSxEpBl3ImG','Dietrich','Amalia','Yundt','consumer@haiyanubills.com','2','353 Lehner Bypass Apt. 768\nEast Jason, FL 59630-7784','A',NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-01-25 17:12:21
