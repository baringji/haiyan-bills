-- MySQL dump 10.13  Distrib 5.5.41, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: haiyanubills
-- ------------------------------------------------------
-- Server version	5.5.41-0ubuntu0.14.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `haiyanubills`
--

/*!40000 DROP DATABASE IF EXISTS `haiyanubills`*/;

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `haiyanubills` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `haiyanubills`;

--
-- Table structure for table `bills`
--

DROP TABLE IF EXISTS `bills`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bills` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `amount` decimal(10,4) NOT NULL,
  `due_date` date NOT NULL,
  `period_start` date NOT NULL,
  `period_end` date NOT NULL,
  `details` text COLLATE utf8_unicode_ci NOT NULL,
  `status` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `bills_user_id_foreign` (`user_id`),
  CONSTRAINT `bills_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bills`
--

LOCK TABLES `bills` WRITE;
/*!40000 ALTER TABLE `bills` DISABLE KEYS */;
INSERT INTO `bills` VALUES (1,'Ledner Group',431674.2301,'2015-01-04','2015-01-24','2015-01-31','Hatter. \'Does YOUR watch tell you my adventures--beginning from this morning,\' said Alice timidly. \'Would you like the Mock Turtle\'s Story \'You can\'t think how glad I am now? That\'ll be a great deal.','O',2,NULL,NULL,NULL),(2,'Doyle-Zieme',988315.4717,'2015-01-21','2015-01-21','2015-01-18','Alice said nothing; she had been jumping about like that!\' But she did it so yet,\' said the Duchess; \'and most things twinkled after that--only the March Hare interrupted, yawning. \'I\'m getting.','O',2,NULL,NULL,NULL),(3,'Lakin-Roob',923667.8459,'2015-01-26','2015-01-31','2015-01-17','Mock Turtle; \'but it doesn\'t understand English,\' thought Alice; but she knew that it might injure the brain; But, now that I\'m doubtful about the games now.\' CHAPTER X. The Lobster Quadrille The.','O',1,NULL,NULL,NULL),(4,'Funk-Rogahn',735610.4646,'2015-01-19','2015-01-16','2015-01-15','I needn\'t be afraid of interrupting him,) \'I\'ll give him sixpence. _I_ don\'t believe it,\' said the King repeated angrily, \'or I\'ll have you executed on the bank, and of having nothing to do.\" Said.','O',2,NULL,NULL,NULL),(5,'Labadie-Zboncak',127420.5761,'2015-01-21','2015-01-31','2015-02-01','Alice. \'That\'s very curious.\' \'It\'s all her coaxing. Hardly knowing what she was dozing off, and found that, as nearly as large as himself, and this was not here before,\' said Alice,) and round goes.','O',1,NULL,NULL,NULL),(6,'Swift, Harvey and Koss',962373.8803,'2015-01-08','2015-01-21','2015-01-17','SOMEBODY ought to have finished,\' said the Mock Turtle is.\' \'It\'s the oldest rule in the book,\' said the King, going up to Alice, they all crowded round her, calling out in a loud, indignant voice,.','O',2,NULL,NULL,NULL),(7,'Paucek, Simonis and Brown',182685.4520,'2015-01-10','2015-01-12','2015-01-18','Duchess; \'and most of \'em do.\' \'I don\'t much care where--\' said Alice. \'Off with her arms round it as far down the chimney close above her: then, saying to herself \'It\'s the stupidest tea-party I.','O',1,NULL,NULL,NULL),(8,'McDermott Inc',687540.8586,'2015-01-19','2015-01-28','2015-01-09','Alice asked in a voice outside, and stopped to listen. The Fish-Footman began by producing from under his arm a great many more than Alice could speak again. In a little bottle on it, and they sat.','O',2,NULL,NULL,NULL),(9,'Reynolds, Cremin and Treutel',633356.3344,'2015-01-29','2015-01-31','2015-01-25','Dodo. Then they all looked so grave that she wanted much to know, but the cook and the jury wrote it down into a cucumber-frame, or something of the e--e--evening, Beautiful, beauti--FUL SOUP!\'.','O',3,NULL,NULL,NULL),(10,'Jaskolski-Feest',270757.4455,'2015-01-12','2015-01-20','2015-02-01','Alice; but she knew she had tired herself out with trying, the poor child, \'for I never knew whether it would feel with all speed back to the Mock Turtle said: \'I\'m too stiff. And the Gryphon never.','O',1,NULL,NULL,NULL),(11,'Nolan PLC',582508.8619,'2015-01-21','2015-01-20','2015-01-06','King. (The jury all brightened up again.) \'Please your Majesty,\' said the Hatter. \'You might just as if it makes rather a complaining tone, \'and they drew all manner of things--everything that.','O',1,NULL,NULL,NULL),(12,'Ankunding, Lemke and Funk',293057.2415,'2015-01-17','2015-01-28','2015-01-22','There was a little while, however, she waited patiently. \'Once,\' said the Cat, as soon as she had but to open them again, and looking anxiously round to see some meaning in it, and then unrolled the.','O',3,NULL,NULL,NULL),(13,'Nienow, McLaughlin and Blanda',153648.7635,'2015-01-04','2015-01-07','2015-01-19','The Dormouse shook itself, and was coming to, but it was impossible to say it any longer than that,\' said the Gryphon: and Alice was too small, but at the Caterpillar\'s making such a rule at.','O',3,NULL,NULL,NULL),(14,'Corwin-Beier',133621.0604,'2015-01-31','2015-01-13','2015-01-09','Alice! when she turned to the Queen, in a sorrowful tone, \'I\'m afraid I am, sir,\' said Alice; not that she knew that were of the doors of the Shark, But, when the race was over. However, when they.','O',1,NULL,NULL,NULL),(15,'Schmitt and Sons',361546.7790,'2015-01-12','2015-01-31','2015-01-16','The chief difficulty Alice found at first was moderate. But the insolence of his tail. \'As if I chose,\' the Duchess to play croquet.\' Then they all spoke at once, while all the time he had taken his.','O',1,NULL,NULL,NULL),(16,'Will, Konopelski and Satterfield',643255.8933,'2015-01-15','2015-01-26','2015-01-27','Gryphon. \'Of course,\' the Mock Turtle, suddenly dropping his voice; and Alice looked all round the court and got behind him, and very soon came to the other, and making quite a new pair of the.','O',1,NULL,NULL,NULL),(17,'Larson-Stokes',719547.9868,'2015-01-22','2015-01-10','2015-01-11','I should like to see the earth takes twenty-four hours to turn round on its axis--\' \'Talking of axes,\' said the others. \'Are their heads downward! The Antipathies, I think--\' (she was obliged to.','O',3,NULL,NULL,NULL),(18,'Schumm LLC',909749.0708,'2015-01-27','2015-01-24','2015-01-31','Duchess\'s cook. She carried the pepper-box in her pocket, and pulled out a history of the Lobster Quadrille?\' the Gryphon never learnt it.\' \'Hadn\'t time,\' said the Caterpillar. \'I\'m afraid I\'ve.','O',2,NULL,NULL,NULL),(19,'O\'Hara-Legros',262538.7634,'2015-01-28','2015-01-19','2015-01-23','Alice waited patiently until it chose to speak again. The Mock Turtle in a very small cake, on which the wretched Hatter trembled so, that Alice said; but was dreadfully puzzled by the pope, was.','O',1,NULL,NULL,NULL),(20,'Brown-Cormier',309555.8069,'2015-01-18','2015-01-26','2015-01-19','I can kick a little!\' She drew her foot slipped, and in THAT direction,\' the Cat remarked. \'Don\'t be impertinent,\' said the Caterpillar. Alice folded her hands, wondering if anything would EVER.','O',2,NULL,NULL,NULL),(21,'Funk-Schmeler',662766.2314,'2015-01-16','2015-01-29','2015-01-18','The Hatter shook his grey locks, \'I kept all my life, never!\' They had not long to doubt, for the White Rabbit, who said in a solemn tone, \'For the Duchess. \'Everything\'s got a moral, if only you.','O',1,NULL,NULL,NULL),(22,'Ledner, Krajcik and Crooks',581141.1085,'2015-01-19','2015-01-27','2015-01-22','VERY tired of this. I vote the young lady to see it quite plainly through the wood. \'If it had fallen into the darkness as hard as it didn\'t much matter which way it was done. They had not gone (We.','O',1,NULL,NULL,NULL),(23,'Hyatt Ltd',795280.3089,'2015-01-19','2015-01-18','2015-01-27','And beat him when he pleases!\' CHORUS. \'Wow! wow! wow!\' While the Owl had the best way to change them--\' when she had hurt the poor little feet, I wonder who will put on her lap as if he doesn\'t.','O',2,NULL,NULL,NULL),(24,'Aufderhar LLC',222710.3114,'2015-01-10','2015-01-20','2015-01-23','All the time she saw in another moment, splash! she was now about two feet high, and her eyes filled with tears again as she went to the door, and tried to open them again, and the arm that was.','O',2,NULL,NULL,NULL),(25,'Corwin Group',719879.1624,'2015-01-13','2015-01-20','2015-01-25','Mock Turtle\'s heavy sobs. Lastly, she pictured to herself \'It\'s the first really clever thing the King and the other players, and shouting \'Off with her head! Off--\' \'Nonsense!\' said Alice, who was.','O',2,NULL,NULL,NULL),(26,'Schinner, Feil and Lebsack',220267.6345,'2015-01-03','2015-01-28','2015-01-20','When the procession came opposite to Alice, \'Have you guessed the riddle yet?\' the Hatter asked triumphantly. Alice did not like to drop the jar for fear of killing somebody, so managed to swallow a.','O',2,NULL,NULL,NULL),(27,'Schiller-Simonis',712808.0302,'2015-01-06','2015-01-08','2015-01-28','Alice ventured to ask. \'Suppose we change the subject,\' the March Hare. \'Exactly so,\' said the Dormouse, who seemed to Alice as she spoke, but no result seemed to think that proved it at last, they.','O',2,NULL,NULL,NULL),(28,'Smitham, Windler and Kuphal',777166.6822,'2015-01-27','2015-01-04','2015-01-11','I shall have to ask them what the flame of a well--\' \'What did they draw the treacle from?\' \'You can draw water out of the tale was something like it,\' said the Pigeon; \'but I know is, something.','O',3,NULL,NULL,NULL),(29,'Lebsack PLC',857525.2170,'2015-01-13','2015-01-19','2015-01-10','The poor little thing howled so, that he shook his grey locks, \'I kept all my life, never!\' They had not gone much farther before she came upon a time she had felt quite unhappy at the moment, \'My.','O',2,NULL,NULL,NULL),(30,'Glover-Gislason',211647.7903,'2015-01-13','2015-01-06','2015-01-30','Hatter. \'I deny it!\' said the sage, as he came, \'Oh! the Duchess, \'chop off her head!\' about once in her lessons in the pool as it was neither more nor less than no time to be Number One,\' said.','O',1,NULL,NULL,NULL),(31,'Goldner-Turner',898294.9591,'2015-01-23','2015-01-06','2015-01-31','And she\'s such a rule at processions; \'and besides, what would happen next. First, she dreamed of little Alice and all her fancy, that: they never executes nobody, you know. But do cats eat bats, I.','O',3,NULL,NULL,NULL),(32,'Klocko-Osinski',643009.0697,'2015-01-10','2015-01-09','2015-01-21','This question the Dodo suddenly called out as loud as she could, for the Duchess and the bright flower-beds and the March Hare interrupted, yawning. \'I\'m getting tired of being upset, and their.','O',1,NULL,NULL,NULL),(33,'Orn-Pacocha',763689.4252,'2015-01-26','2015-01-21','2015-01-27','I shall ever see you any more!\' And here poor Alice in a melancholy tone: \'it doesn\'t seem to encourage the witness at all: he kept shifting from one end of the Lobster; I heard him declare, \"You.','O',2,NULL,NULL,NULL),(34,'Swaniawski, Tillman and Conroy',275442.6821,'2015-01-19','2015-01-13','2015-01-14','YET,\' she said to herself; \'the March Hare went on. \'I do,\' Alice said nothing; she had never seen such a new pair of the gloves, and she dropped it hastily, just in time to be treated with respect..','O',3,NULL,NULL,NULL),(35,'Kub and Sons',669990.9497,'2015-01-18','2015-01-18','2015-01-26','Alice had learnt several things of this ointment--one shilling the box-- Allow me to him: She gave me a good deal frightened at the flowers and those cool fountains, but she could have been a RED.','O',3,NULL,NULL,NULL),(36,'Koepp, Bartell and Kuhic',523965.3924,'2015-01-31','2015-01-03','2015-01-24','Alice sharply, for she was now about a foot high: then she heard the Queen\'s shrill cries to the Gryphon. \'Well, I never knew whether it was very provoking to find that the way out of the March Hare.','O',2,NULL,NULL,NULL),(37,'Gleichner-Corwin',763905.9859,'2015-01-03','2015-01-27','2015-01-13','The Gryphon sat up and went to school in the schoolroom, and though this was her dream:-- First, she dreamed of little Alice and all must have a trial: For really this morning I\'ve nothing to what I.','O',1,NULL,NULL,NULL),(38,'Dooley Inc',118071.3412,'2015-01-24','2015-01-21','2015-01-02','Alice, \'when one wasn\'t always growing larger and smaller, and being so many different sizes in a moment to be two people! Why, there\'s hardly room for her. \'Yes!\' shouted Alice. \'Come on, then!\'.','O',1,NULL,NULL,NULL),(39,'Marquardt, Herman and Marquardt',573793.0841,'2015-01-21','2015-01-05','2015-01-14','Hatter. \'He won\'t stand beating. Now, if you drink much from a Caterpillar The Caterpillar and Alice thought this must be off, and found that, as nearly as she swam about, trying to box her own.','O',1,NULL,NULL,NULL),(40,'Rogahn-Hodkiewicz',8030.6729,'2015-01-29','2015-02-02','2015-01-31','Presently she began thinking over other children she knew that were of the edge of her skirt, upsetting all the children she knew, who might do something better with the bread-knife.\' The March Hare.','O',1,NULL,NULL,NULL),(41,'Halvorson and Sons',862258.3184,'2015-01-26','2015-01-22','2015-01-19','I think--\' (for, you see, as well as she went on again:-- \'I didn\'t mean it!\' pleaded poor Alice in a helpless sort of a procession,\' thought she, \'if people had all to lie down upon her: she gave a.','O',1,NULL,NULL,NULL),(42,'Robel, Hansen and Kihn',604721.9918,'2015-01-15','2015-01-12','2015-01-20','Queen. An invitation from the Gryphon, \'you first form into a line along the sea-shore--\' \'Two lines!\' cried the Gryphon, the squeaking of the tail, and ending with the game,\' the Queen said.','O',1,NULL,NULL,NULL),(43,'Green Ltd',913810.8620,'2015-01-30','2015-01-14','2015-01-29','CAN all that green stuff be?\' said Alice. \'Did you say things are worse than ever,\' thought the whole party at once set to partners--\' \'--change lobsters, and retire in same order,\' continued the.','O',3,NULL,NULL,NULL),(44,'Dibbert-Ratke',974340.4480,'2015-01-20','2015-01-25','2015-01-22','Queen, and in another moment, splash! she was trying to put the hookah out of their wits!\' So she set off at once, she found this a good deal: this fireplace is narrow, to be Involved in this way!.','O',1,NULL,NULL,NULL),(45,'Von, Brekke and Walter',210856.7932,'2015-01-13','2015-01-20','2015-01-14','Hatter went on, \'What\'s your name, child?\' \'My name is Alice, so please your Majesty,\' he began. \'You\'re a very melancholy voice. \'Repeat, \"YOU ARE OLD, FATHER WILLIAM,\"\' said the Dormouse, without.','O',2,NULL,NULL,NULL),(46,'Dickens and Sons',970535.6875,'2015-02-01','2015-01-06','2015-01-29','The Cat only grinned a little now and then they wouldn\'t be so proud as all that.\' \'With extras?\' asked the Mock Turtle angrily: \'really you are very dull!\' \'You ought to be otherwise than what it.','O',1,NULL,NULL,NULL),(47,'Lueilwitz, Bradtke and Hegmann',505020.7083,'2015-01-24','2015-01-13','2015-01-17','Hatter. \'You MUST remember,\' remarked the King, the Queen, who was reading the list of singers. \'You may go,\' said the Dodo suddenly called out \'The Queen! The Queen!\' and the Queen said to herself..','O',2,NULL,NULL,NULL),(48,'Hilpert Inc',561838.5570,'2015-02-02','2015-01-17','2015-01-14','As she said to herself, and nibbled a little of the trees as well as she could, for the next verse,\' the Gryphon interrupted in a sorrowful tone; \'at least there\'s no meaning in it, and very soon.','O',1,NULL,NULL,NULL),(49,'McDermott Inc',688102.7399,'2015-01-18','2015-01-05','2015-01-29','I didn\'t know it was only the pepper that had fallen into it: there were three little sisters,\' the Dormouse denied nothing, being fast asleep. \'After that,\' continued the King. \'I can\'t explain.','O',2,NULL,NULL,NULL),(50,'Johnson-Blick',285136.0673,'2015-01-05','2015-02-02','2015-01-30','Alice, a little girl or a worm. The question is, what did the Dormouse sulkily remarked, \'If you please, sir--\' The Rabbit Sends in a tone of the Gryphon, \'she wants for to know what to beautify is,.','O',2,NULL,NULL,NULL);
/*!40000 ALTER TABLE `bills` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `files`
--

DROP TABLE IF EXISTS `files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `files` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `file_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `file_type` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `file_type_id` int(10) unsigned NOT NULL,
  `is_primary` tinyint(1) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `files`
--

LOCK TABLES `files` WRITE;
/*!40000 ALTER TABLE `files` DISABLE KEYS */;
/*!40000 ALTER TABLE `files` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `landmarks`
--

DROP TABLE IF EXISTS `landmarks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `landmarks` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `type` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `landmarks`
--

LOCK TABLES `landmarks` WRITE;
/*!40000 ALTER TABLE `landmarks` DISABLE KEYS */;
INSERT INTO `landmarks` VALUES (1,'Hettinger-Shanahan','CHURCH',NULL,NULL,NULL),(2,'Maggio and Sons','MALL',NULL,NULL,NULL),(3,'Dicki PLC','CHURCH',NULL,NULL,NULL),(4,'Koch-Gusikowski','PARK',NULL,NULL,NULL),(5,'Friesen Inc','CHURCH',NULL,NULL,NULL),(6,'Lubowitz-Skiles','PARK',NULL,NULL,NULL),(7,'Jerde, Ondricka and Gorczany','PARK',NULL,NULL,NULL),(8,'Morissette LLC','CHURCH',NULL,NULL,NULL),(9,'Weber-Green','CHURCH',NULL,NULL,NULL),(10,'Connelly-Turner','MALL',NULL,NULL,NULL),(11,'Hickle-Ruecker','BUILDING',NULL,NULL,NULL),(12,'Gorczany PLC','MALL',NULL,NULL,NULL),(13,'Von, Dietrich and Walker','PARK',NULL,NULL,NULL),(14,'Wiza-Padberg','CHURCH',NULL,NULL,NULL),(15,'Moore, Hirthe and Cassin','PARK',NULL,NULL,NULL),(16,'Runolfsdottir-Herman','MALL',NULL,NULL,NULL),(17,'Harris-Haley','CHURCH',NULL,NULL,NULL),(18,'Veum LLC','BUILDING',NULL,NULL,NULL),(19,'Olson-Schaden','CHURCH',NULL,NULL,NULL),(20,'Hoppe, Bechtelar and Littel','BUILDING',NULL,NULL,NULL),(21,'Barrows-Hoppe','CHURCH',NULL,NULL,NULL),(22,'Schroeder, Schoen and Hand','HOTEL',NULL,NULL,NULL),(23,'Koss PLC','HOTEL',NULL,NULL,NULL),(24,'Kemmer-Wolff','CHURCH',NULL,NULL,NULL),(25,'Schimmel Inc','HOTEL',NULL,NULL,NULL),(26,'Torp, Cartwright and Stokes','MALL',NULL,NULL,NULL),(27,'Stokes-Thiel','HOTEL',NULL,NULL,NULL),(28,'Erdman, Halvorson and Ryan','CHURCH',NULL,NULL,NULL),(29,'Reinger, Oberbrunner and Stanton','HOTEL',NULL,NULL,NULL),(30,'Jones PLC','MALL',NULL,NULL,NULL),(31,'Cole LLC','MALL',NULL,NULL,NULL),(32,'Dare, Walter and Mueller','CHURCH',NULL,NULL,NULL),(33,'Tromp Group','BUILDING',NULL,NULL,NULL),(34,'Conroy Ltd','HOTEL',NULL,NULL,NULL),(35,'Boehm, Bosco and White','HOTEL',NULL,NULL,NULL),(36,'Greenfelder, Funk and Casper','MALL',NULL,NULL,NULL),(37,'Daniel, Kuhic and Conroy','BUILDING',NULL,NULL,NULL),(38,'Terry, Cartwright and Leuschke','CHURCH',NULL,NULL,NULL),(39,'Beahan Inc','HOTEL',NULL,NULL,NULL),(40,'Breitenberg-Huel','HOTEL',NULL,NULL,NULL),(41,'Yundt LLC','PARK',NULL,NULL,NULL),(42,'Ryan-Wilderman','PARK',NULL,NULL,NULL),(43,'Rolfson LLC','PARK',NULL,NULL,NULL),(44,'Schamberger, Schaefer and Reynolds','HOTEL',NULL,NULL,NULL),(45,'Swaniawski, Mann and Ankunding','CHURCH',NULL,NULL,NULL),(46,'Huel, Bayer and Kassulke','BUILDING',NULL,NULL,NULL),(47,'Kihn Inc','PARK',NULL,NULL,NULL),(48,'Cremin-Jaskolski','PARK',NULL,NULL,NULL),(49,'Lehner-Bartoletti','CHURCH',NULL,NULL,NULL),(50,'Maggio, Pfannerstill and Renner','MALL',NULL,NULL,NULL);
/*!40000 ALTER TABLE `landmarks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `migration` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES ('2015_01_25_072304_create_table_users',1),('2015_01_25_072836_create_table_files',1),('2015_01_25_073429_create_table_bills',1),('2015_01_25_074124_create_table_receipts',1),('2015_01_25_075327_create_table_payment_centers',1),('2015_01_25_075841_create_table_landmarks',1),('2015_01_25_080038_create_table_payment_centers_landmarks',1),('2015_01_26_140648_create_table_notes',1);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notes`
--

DROP TABLE IF EXISTS `notes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `details` text COLLATE utf8_unicode_ci NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `notes_user_id_foreign` (`user_id`),
  CONSTRAINT `notes_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notes`
--

LOCK TABLES `notes` WRITE;
/*!40000 ALTER TABLE `notes` DISABLE KEYS */;
/*!40000 ALTER TABLE `notes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payment_centers`
--

DROP TABLE IF EXISTS `payment_centers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payment_centers` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `city` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `country` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `zip` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `latitude` float(8,2) NOT NULL,
  `longitude` float(8,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payment_centers`
--

LOCK TABLES `payment_centers` WRITE;
/*!40000 ALTER TABLE `payment_centers` DISABLE KEYS */;
INSERT INTO `payment_centers` VALUES (1,'Zboncak Group','162 Berge Camp Apt. 835','Lake Virginia','Falkland Islands (Malvinas)','09908',66.11,-15.29,NULL,NULL,NULL),(2,'Feeney, Batz and Stokes','81866 Arely Bypass Suite 323','Delorestown','Palestinian Territory','56598-3067',-4.63,-23.92,NULL,NULL,NULL),(3,'Pfannerstill Inc','26036 Schamberger Points','South Carleton','Korea','62827-2188',-78.23,-69.24,NULL,NULL,NULL),(4,'Wolff Inc','6209 Shanie Springs','Lake Adriennemouth','Austria','13200-1790',-22.93,138.43,NULL,NULL,NULL),(5,'Wisoky, Hermann and Lowe','3356 Stroman Street Apt. 687','Nashville','Svalbard & Jan Mayen Islands','37258-1951',-67.75,19.12,NULL,NULL,NULL),(6,'Abbott Inc','261 Leo Stream Suite 792','East Shania','Malta','00080',-29.75,8.25,NULL,NULL,NULL),(7,'Shields-Fadel','55285 Weimann Ways Suite 683','Marisaside','Mayotte','23203-0354',29.60,27.36,NULL,NULL,NULL),(8,'Gutmann-Langworth','9864 Tyson Run','Spinkabury','Guinea','59255',-18.25,160.34,NULL,NULL,NULL),(9,'Baumbach-Wilderman','60989 Thalia Oval Apt. 078','Stromanburgh','Maldives','72973',35.95,85.75,NULL,NULL,NULL),(10,'Halvorson, Satterfield and Wintheiser','7563 Yesenia Inlet Apt. 864','West Madisynside','Netherlands Antilles','66648-3218',-62.54,156.01,NULL,NULL,NULL),(11,'Turcotte, Harvey and Wiza','3448 Brandon Knolls','North Juliohaven','Norfolk Island','46442-4934',24.73,169.40,NULL,NULL,NULL),(12,'Rohan Ltd','7059 Berge Trail','Port Craig','Norway','71282',-21.83,137.98,NULL,NULL,NULL),(13,'Kutch Group','0005 Trisha Falls','New Jermey','Afghanistan','95417',-45.20,141.60,NULL,NULL,NULL),(14,'Huels-Dicki','181 Napoleon Lane','Hammeshaven','Antarctica (the territory South of 60 deg S)','93356-7346',-18.78,-171.03,NULL,NULL,NULL),(15,'Harber Group','42630 Barton Square Apt. 466','Champlinland','Seychelles','34325-4901',-59.08,14.40,NULL,NULL,NULL),(16,'Boyer Inc','018 Mylene Flat','Angelaport','Monaco','38438',-24.96,-106.13,NULL,NULL,NULL),(17,'Mills Ltd','43878 Elfrieda Court','East Cary','Azerbaijan','12941-1728',-20.54,146.81,NULL,NULL,NULL),(18,'Mueller-Russel','18522 Berenice Fields Apt. 079','Gwenberg','Wallis and Futuna','41835-5139',-30.77,87.40,NULL,NULL,NULL),(19,'Zemlak, Schmitt and Sporer','2240 Rolfson Station Suite 181','Port Paytonside','Benin','64926-6196',-43.30,-49.25,NULL,NULL,NULL),(20,'Reinger Ltd','730 Rolfson Mews Apt. 795','Princemouth','Venezuela','33202',-79.86,-49.71,NULL,NULL,NULL),(21,'Mitchell Group','505 Andreanne Ramp','South Brittanybury','Sri Lanka','09779',9.22,-29.65,NULL,NULL,NULL),(22,'Hoeger-Schuster','93408 Kailee Glens','Port Conniemouth','Macao','86707',73.07,164.06,NULL,NULL,NULL),(23,'Howe, Zboncak and Koss','43374 Garrett Alley','North Reyna','Liberia','69498',-34.23,3.07,NULL,NULL,NULL),(24,'Farrell, Powlowski and O\'Connell','73786 Hailee Well Suite 762','Port Carlotta','Tonga','26517-0198',36.96,135.49,NULL,NULL,NULL),(25,'O\'Keefe, Bergnaum and Satterfield','639 Lori Route','Sistermouth','New Caledonia','44390',-18.32,85.78,NULL,NULL,NULL),(26,'Hessel Ltd','00577 Schmitt Mountain','Naderton','Saint Kitts and Nevis','65039',-48.70,96.27,NULL,NULL,NULL),(27,'Boyer-Frami','381 Gustave Plains','O\'Harachester','South Africa','82374',-16.56,-143.08,NULL,NULL,NULL),(28,'Wisozk, Kerluke and Hoppe','2736 Stroman Island','Fritschborough','India','85791',-35.02,-0.80,NULL,NULL,NULL),(29,'Stiedemann LLC','0727 Quigley Mission','South Darby','Zambia','17384',0.29,-30.47,NULL,NULL,NULL),(30,'Kozey, Veum and Oberbrunner','5308 Nikolaus Ramp Apt. 468','Lake Estrellamouth','Christmas Island','06010-5250',-10.95,-28.59,NULL,NULL,NULL),(31,'Bashirian, Rowe and Torp','7394 Mayer Glens','Larryborough','Macao','35783-4598',49.31,69.56,NULL,NULL,NULL),(32,'Upton-Wiza','893 Considine Mill','Lake Fermin','Lao People\'s Democratic Republic','30289-7282',-52.90,-47.93,NULL,NULL,NULL),(33,'O\'Hara LLC','458 Schuppe Dam Apt. 083','Port Renee','Slovenia','96879-9944',-46.73,-93.49,NULL,NULL,NULL),(34,'Franecki-Ortiz','65768 Marquardt Bypass Apt. 635','South Ellsworthville','Mauritania','94951-1403',-78.96,-108.50,NULL,NULL,NULL),(35,'Shanahan Ltd','150 Reichel Springs','Zulaufville','Italy','52147-2471',-29.13,73.12,NULL,NULL,NULL),(36,'Collins PLC','442 Doyle Plains Apt. 871','Rheaton','Nauru','34292-5961',-13.55,-3.00,NULL,NULL,NULL),(37,'DuBuque-Kutch','45691 Annette Shore','New Ephraim','New Zealand','75573',48.83,67.82,NULL,NULL,NULL),(38,'McLaughlin, Quitzon and Murazik','0061 Zola Tunnel','Bartellchester','Israel','32918',-61.44,121.11,NULL,NULL,NULL),(39,'Kuhn Ltd','3665 Wolff Spurs','Gracietown','Christmas Island','80767',-51.28,-10.78,NULL,NULL,NULL),(40,'Harvey, Bednar and Schumm','84547 Prohaska Plain','North Zoila','Burundi','06784-1106',-38.04,67.77,NULL,NULL,NULL),(41,'Frami, Koepp and Armstrong','7652 DuBuque Haven Apt. 961','East Lisa','Belize','47598',-10.97,-123.37,NULL,NULL,NULL),(42,'Kerluke-Will','81811 Shayna Ports Apt. 720','Rennerbury','Northern Mariana Islands','13264-8963',-69.74,-93.12,NULL,NULL,NULL),(43,'Dickens-Lindgren','7468 Kameron Lane','Octaviabury','Austria','27435-9195',-5.92,-56.92,NULL,NULL,NULL),(44,'Johnston, Kessler and Bashirian','17693 Weber Village Apt. 442','Langchester','Egypt','22102',-3.28,-87.04,NULL,NULL,NULL),(45,'Gorczany, Schowalter and Hansen','6538 Neal Port','Norristown','Lithuania','32625-3370',-25.69,-9.91,NULL,NULL,NULL),(46,'Lueilwitz, Cormier and Beahan','0983 Hyatt Extensions Suite 503','Hackettfort','Papua New Guinea','37157',51.13,-121.01,NULL,NULL,NULL),(47,'Weissnat-Kuphal','5100 Cummerata Tunnel','Twilamouth','El Salvador','92813',-24.39,97.80,NULL,NULL,NULL),(48,'Stark, Huels and Runte','2965 Arnold Plain Suite 920','Rempelborough','Falkland Islands (Malvinas)','57268-4274',-77.14,11.98,NULL,NULL,NULL),(49,'Prohaska, Kovacek and Auer','6227 Matilda Fords Apt. 914','Kenyonport','Gibraltar','31872-3353',19.16,-25.74,NULL,NULL,NULL),(50,'Crist and Sons','814 Kennith Springs Apt. 832','New Alessandro','Uganda','05263-3512',-45.45,54.54,NULL,NULL,NULL);
/*!40000 ALTER TABLE `payment_centers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payment_centers_landmarks`
--

DROP TABLE IF EXISTS `payment_centers_landmarks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payment_centers_landmarks` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `payment_center_id` int(10) unsigned NOT NULL,
  `landmark_id` int(10) unsigned NOT NULL,
  `latitude` float(8,2) NOT NULL,
  `longitude` float(8,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `payment_centers_landmarks_payment_center_id_foreign` (`payment_center_id`),
  KEY `payment_centers_landmarks_landmark_id_foreign` (`landmark_id`),
  CONSTRAINT `payment_centers_landmarks_landmark_id_foreign` FOREIGN KEY (`landmark_id`) REFERENCES `landmarks` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `payment_centers_landmarks_payment_center_id_foreign` FOREIGN KEY (`payment_center_id`) REFERENCES `payment_centers` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payment_centers_landmarks`
--

LOCK TABLES `payment_centers_landmarks` WRITE;
/*!40000 ALTER TABLE `payment_centers_landmarks` DISABLE KEYS */;
INSERT INTO `payment_centers_landmarks` VALUES (1,5,24,72.99,-73.52,NULL,NULL,NULL),(2,41,44,64.99,-176.87,NULL,NULL,NULL),(3,42,7,87.86,-32.85,NULL,NULL,NULL),(4,38,12,83.76,-131.10,NULL,NULL,NULL),(5,21,36,26.26,-90.21,NULL,NULL,NULL),(6,25,26,1.91,-165.31,NULL,NULL,NULL),(7,23,47,87.60,-71.54,NULL,NULL,NULL),(8,49,42,67.57,-105.19,NULL,NULL,NULL),(9,48,40,67.63,-121.12,NULL,NULL,NULL),(10,4,15,19.40,64.34,NULL,NULL,NULL),(11,21,7,8.47,-7.22,NULL,NULL,NULL),(12,14,47,23.59,-144.90,NULL,NULL,NULL),(13,15,19,-30.51,98.10,NULL,NULL,NULL),(14,10,41,38.78,138.56,NULL,NULL,NULL),(15,8,45,89.85,117.04,NULL,NULL,NULL),(16,12,12,-4.58,-138.99,NULL,NULL,NULL),(17,18,3,-53.04,169.82,NULL,NULL,NULL),(18,6,9,-28.29,-162.99,NULL,NULL,NULL),(19,9,43,5.41,-7.24,NULL,NULL,NULL),(20,21,30,-82.36,-15.61,NULL,NULL,NULL),(21,29,46,5.90,-116.54,NULL,NULL,NULL),(22,5,2,21.37,-72.62,NULL,NULL,NULL),(23,43,3,66.07,-95.26,NULL,NULL,NULL),(24,43,40,-87.70,118.65,NULL,NULL,NULL),(25,43,47,-5.06,-166.39,NULL,NULL,NULL),(26,5,14,-85.48,-13.15,NULL,NULL,NULL),(27,4,18,37.62,55.26,NULL,NULL,NULL),(28,10,18,-46.86,-22.88,NULL,NULL,NULL),(29,37,20,75.68,133.39,NULL,NULL,NULL),(30,9,44,-77.80,112.18,NULL,NULL,NULL),(31,15,20,-85.59,121.69,NULL,NULL,NULL),(32,6,32,75.11,-59.76,NULL,NULL,NULL),(33,22,11,-2.94,105.55,NULL,NULL,NULL),(34,41,31,-21.42,116.08,NULL,NULL,NULL),(35,4,11,-80.55,119.78,NULL,NULL,NULL),(36,10,32,-23.39,44.02,NULL,NULL,NULL),(37,7,15,-28.01,166.35,NULL,NULL,NULL),(38,34,49,7.54,69.16,NULL,NULL,NULL),(39,18,26,69.21,25.09,NULL,NULL,NULL),(40,39,10,-87.01,-171.43,NULL,NULL,NULL),(41,23,43,-30.42,-49.78,NULL,NULL,NULL),(42,23,26,0.89,-78.24,NULL,NULL,NULL),(43,11,33,-34.48,-123.35,NULL,NULL,NULL),(44,44,47,-71.53,154.47,NULL,NULL,NULL),(45,3,2,63.88,-20.69,NULL,NULL,NULL),(46,41,17,-34.12,-147.18,NULL,NULL,NULL),(47,21,46,9.20,52.95,NULL,NULL,NULL),(48,48,43,6.84,-1.67,NULL,NULL,NULL),(49,7,39,-41.87,93.91,NULL,NULL,NULL),(50,24,10,36.47,67.48,NULL,NULL,NULL);
/*!40000 ALTER TABLE `payment_centers_landmarks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `receipts`
--

DROP TABLE IF EXISTS `receipts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `receipts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `amount` decimal(10,4) NOT NULL,
  `bill_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `receipts_bill_id_foreign` (`bill_id`),
  CONSTRAINT `receipts_bill_id_foreign` FOREIGN KEY (`bill_id`) REFERENCES `bills` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `receipts`
--

LOCK TABLES `receipts` WRITE;
/*!40000 ALTER TABLE `receipts` DISABLE KEYS */;
INSERT INTO `receipts` VALUES (1,432656.0559,34,NULL,NULL,NULL),(2,705351.8481,46,NULL,NULL,NULL),(3,751415.6970,32,NULL,NULL,NULL),(4,324337.5531,4,NULL,NULL,NULL),(5,566436.9176,26,NULL,NULL,NULL),(6,364373.5754,13,NULL,NULL,NULL),(7,266675.3421,33,NULL,NULL,NULL),(8,644861.1295,9,NULL,NULL,NULL),(9,416274.7955,7,NULL,NULL,NULL),(10,986157.2819,14,NULL,NULL,NULL);
/*!40000 ALTER TABLE `receipts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `last_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `first_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `middle_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `user_type` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `address` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'administrator','$2y$10$Govu9Sdz46HPttpr7mRqneSqrZdTmE4i9M4c6.pwIlX.N2GAteAu2','Kshlerin','Katherine','Jerde','administrator@haiyanubills.com','0','9705 Jenifer Extension Apt. 303\nWest Michale, CA 23040','A',NULL,NULL,NULL,NULL),(2,'admin','$2y$10$il7OnUCZd3epwJ.gMhDOlukzbAkgM9BMu8XyaWkqOAbAArBxBD4hm','Hagenes','Alana','Ebert','admin@haiyanubills.com','1','57315 Ondricka Via\nZboncakport, RI 13789','A',NULL,NULL,NULL,NULL),(3,'consumer','$2y$10$aTW1Z4SHuCUQ0S6sqG3ST.kYfNe2EKLaAFHlr7R.pJ7X/EE4Z/sRq','Schoen','Jefferey','Haley','consumer@haiyanubills.com','2','0338 Kovacek Roads Apt. 503\nNorth Colinton, MA 83575-3988','A',NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-02-02 21:23:10
